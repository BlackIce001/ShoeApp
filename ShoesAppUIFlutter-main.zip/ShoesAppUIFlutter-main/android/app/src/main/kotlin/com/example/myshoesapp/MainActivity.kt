package com.example.myshoesapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
